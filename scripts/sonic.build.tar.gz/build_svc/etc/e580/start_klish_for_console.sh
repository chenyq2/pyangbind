export PYTHONPATH='/usr/lib/python2.7:/usr/lib/python2.7/site-packages:/usr/lib/python2.7/site-packages/rpc_server/lib/'
export PYTHONHOME='/usr'
export PATH=$PATH:/usr/local/openvswitch/bin
klish
