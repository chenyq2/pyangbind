# telnetd login command 
klish

