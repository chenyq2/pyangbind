#!/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function, unicode_literals, division

import os
import re
import sys
import getopt
import commands

USAGE = """
Usage: {fname} OPTION
Add or delete openflow controller.

  -o, --operate=OPER      'add' or 'del'
  -i, --inband            Specific inband to connect controller
  -a, --address=IPADDR    controller ip address
  -p, --port=PORT         controller port number
  -t, --type=TYPE         'tcp' or 'ssl', protocol type
  -b, --bind=IFACE        bind interface
  -l, --localip=IPADDR    bind ip address
  -e, --binden=ENABLE     enable bind local address
""".format(fname=os.path.basename(__file__))

def usage():
    print(USAGE)
    exit(1)

def parse_args(args):
    config = {
        'is_add': False,
        'is_inband': False,
        'address': '',
        'port': 0,
        'protocol': '',
        'iface': '',
        'localip': '',
        'bind_en': False
    }

    if len(args) <= 1:
        usage()

    try:
        opts, args = getopt.gnu_getopt(args, 'o:ia:p:t:b:l:e', 
                ['operate=', 'inband', 'address=', 'port=', 'type=', 'bind=', 'localip=', 'binden'])
    except Exception:
        usage()

    for opt, val in opts:
        if opt in ['-o', '--oper']:
            config['is_add'] = True if val == 'add' else False
        elif opt in ['-i', '--inband']:
            config['is_inband'] = True
        elif opt in ['-a', '--address']:
            config['address'] = val
        elif opt in ['-p', '--port']:
            config['port'] = val
        elif opt in ['-t', '--type']:
            config['protocol'] = val
        elif opt in ['-b', '--bind']:
            config['iface'] = val
        elif opt in ['-l', '--localip']:
            config['localip'] = val
        elif opt in ['-l', '--localip']:
            config['localip'] = val
        elif opt in ['-e', '--binden']:
            config['bind_en'] = True
        else:
            usage()

    return config

def of_protocol_to_int(protocol):
    if protocol == 'tcp':
        return 0
    elif protocol == 'udp':
        return 1
    elif protocol == 'ssl':
        return 2
    else:
        raise ValueError('% Unknow protocol "{}"'.format(protocol))

def of_int_to_protocol(num):
    num = int(num)

    if num == 0:
        return 'tcp'
    elif num == 1:
        return 'udp'
    elif num == 2:
        return 'ssl'
    else:
        raise ValueError('% Unknow protocol type "{}"'.format(num))

def protocol_to_int(protocol):
    if protocol in ['tcp', 'ssl']:
        return 0
    else:
        return 1

def add_ns_route(ip, port, protocol, is_inband):
    cmd = ('cdbctl create/cdb/sys/ns_route/'
           '{protocol}#{port}#{addr}/1/{inband}/'
           .format(protocol=protocol, port=port, addr=ip,
                   inband='inband' if is_inband else 'outband'))

    return os.system(cmd) >> 8

def del_ns_route(ip, port, protocol):
    cmd = ('cdbctl delete/cdb/sys/ns_route/'
           '{protocol}#{port}#{addr}/'
           .format(protocol=protocol, port=port, addr=ip))

    return os.system(cmd) >> 8

def add_inband_snat(ip, port, protocol, bind_en, iface, localip):
    if not bind_en:
        return 0

    cmd = ('cdbctl create/cdb/sys/inband_snat/'
           '{protocol}#{port}#{addr}/'
           'type/1/ifname/{bind_if}/ip/{bind_addr}/'
           .format(protocol=protocol, port=port, addr=ip, bind_if=iface, bind_addr=localip))

    return os.system(cmd) >> 8

def del_inband_snat(ip, port, protocol):
    cmd = ('cdbctl delete/cdb/sys/inband_snat/'
           '{protocol}#{port}#{addr}/'
           .format(protocol=protocol, port=port, addr=ip))

    return os.system(cmd) >> 8

def refresh_controller():
    output = commands.getoutput('cdbctl read/cdb/sys/ns_route | grep flag=1')

    # delete all controller
    if not output.strip():
        cmd = 'ovs-vsctl del-controller-centec br0'
        return os.system(cmd)

    # refresh controller
    ctrl_arr = []
    for line in output.split('\n'):
        key = re.findall(r'/key=(.*?)/|$', line)[0]
        protocol, port, ip = key.split('#')
        protocol = of_int_to_protocol(protocol)
        ctrl_arr.append(':'.join([protocol, ip, port]))

    cmd = 'ovs-vsctl set-controller-centec br0 {}'.format(' '.join(ctrl_arr))

    return os.system(cmd) >> 8

def add_inband(ip, port, protocol, bind_en, iface, localip):
    res = add_inband_snat(ip, port, protocol_to_int(protocol), bind_en, iface, localip)
    if res:
        del_inband_snat(ip, port, protocol_to_int(protocol))
        return

    res = add_ns_route(ip, port, of_protocol_to_int(protocol), True)
    if res:
        return

def add_outband(ip, port, protocol):
    res = add_ns_route(ip, port, of_protocol_to_int(protocol), False)
    if res:
        return
        
def del_controller(ip, port, protocol):
    del_ns_route(ip, port, of_protocol_to_int(protocol))
    del_inband_snat(ip, port, protocol_to_int(protocol))

def limit_controller_count():
    output = int(commands.getoutput('cdbctl read/cdb/sys/ns_route | grep flag=1 | wc -l'))
    if output >= 3:
        print('% The number of controller should not exceed 3')
        sys.exit(1)

def main():
    config = parse_args(sys.argv[1:])

    if config['is_add']:
        limit_controller_count()

        if config['is_inband']:
            add_inband(config['address'], config['port'], config['protocol'],
                       config['bind_en'], config['iface'], config['localip'])
        else:
            add_outband(config['address'], config['port'], config['protocol'])
    else:
        del_controller(config['address'], config['port'], config['protocol'])

    refresh_controller()


if __name__ == '__main__':
    main()


