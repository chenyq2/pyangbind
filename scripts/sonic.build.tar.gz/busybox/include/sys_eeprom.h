int read_sys_eeprom(void *eeprom_data, int offset, int len);
int write_sys_eeprom(void *eeprom_data, int len);
